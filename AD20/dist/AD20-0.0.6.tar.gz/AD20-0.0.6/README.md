AD20 package by Group 20:
Lindsey Brown
Xinyue Wang
Kevin Yoon

For documentation, see https://github.com/CS207-AD20/cs207-FinalProject.
